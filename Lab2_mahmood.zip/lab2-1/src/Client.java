public abstract class Client { 
   public abstract void readData();
   public abstract void processData(); 
   public abstract void printData(); 
}